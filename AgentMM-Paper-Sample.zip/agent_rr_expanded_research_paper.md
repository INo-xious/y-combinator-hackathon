# Deterministic Time-Travel Debugging for Non-Deterministic AI Agents

**A Causal-DAG Flight Recorder, Local Replay Engine, and Regression Testing Framework for Production Agent Failures**  
Expanded research paper for **Agent-RR** / `github.com/INo-xious/y-combinator-hackathon`

---

## Abstract

AI agents are moving from demos into production workflows where they call tools, mutate state, query databases, invoke APIs, and coordinate with other agents. This creates a reproducibility gap: the same prompt and code path can yield a different model action, a different tool observation, or a different multi-agent ordering during debugging. The result is cascading state drift: once a single boundary event differs, every downstream prompt, tool call, and decision may no longer represent the original failure.

This paper presents **Agent-RR**, a deterministic replay approach for AI-agent reliability engineering. Agent-RR records each non-deterministic boundary event - LLM calls, tool calls, HTTP/API calls, database reads, state mutations, and agent messages - as a hash-linked node in a causal directed acyclic graph (DAG). During local replay, Agent-RR returns historical responses instead of contacting live production systems, allowing developers to reproduce failures, bisect divergence, and run zero-network regression tests in CI. Compared with flat logs, transport-level cassettes, or passive observability traces, the contribution is execution control: every replay can be strict, structured, semantic, or manually injected, while preserving causal ordering and blocking unsafe side effects.

The paper expands the original concept with industry statistics, a formal stochastic model of agent execution, a probability model for replay divergence, a causal hash-chain trace schema, a topological replay scheduler, operational threat analysis, evaluation methodology, and a reference architecture aligned with the current Agent-RR README and prototype.

---

## 1. Why This Problem Matters Now

Agentic AI is no longer just a research phrase. PwC reported in May 2025 that among 300 senior executives, 79% said AI agents were already being adopted in their companies, 88% planned to increase AI-related budgets in the next 12 months due to agentic AI, and 66% of adopters reported measurable value through increased productivity [1]. LangChain surveyed more than 1,300 professionals in 2026 and reported that 57% had agents in production, while 32% cited quality as a top barrier and 89% had implemented observability for agents [2].

At the same time, the operational evidence suggests that production agents are intentionally constrained because reliability is still weak. A large-scale study of production agents surveyed 306 practitioners and conducted 20 case studies across 26 domains. It found that 68% of deployed agents execute at most ten steps before human intervention, 47% execute fewer than five steps, 70% rely on prompting off-the-shelf models rather than weight tuning, and 74% depend primarily on human evaluation. The study identified reliability as the top development challenge [3].

The business risk is visible at the portfolio level. Reuters reported Gartner's forecast that more than 40% of agentic AI projects would be canceled by the end of 2027 because of escalating costs and unclear business value. The same report cited Gartner predictions that by 2028, 15% of day-to-day work decisions would be made autonomously by agentic AI and 33% of enterprise software applications would include agentic AI [4]. In other words: adoption pressure is increasing, but reproducibility and verification are lagging.

| Signal | Statistic | Why it matters for Agent-RR |
|---|---:|---|
| Agent adoption | 79% of surveyed executives say agents are being adopted; 88% expect budget increases [1] | Teams are moving agents into real workflows, so failures become production reliability issues. |
| Production maturity | 57% of LangChain respondents report agents in production; quality is a top barrier for 32% [2] | Debugging and regression testing become key bottlenecks. |
| Bounded autonomy | 68% of production agents execute <=10 steps before human intervention; 47% execute <5 steps [3] | Teams deliberately limit autonomy because long-horizon replay and validation are difficult. |
| Human evaluation | 74% of production agents rely primarily on human evaluation [3] | Manual review does not scale to every prompt, model, and tool change. |
| Project attrition | Gartner forecast: >40% of agentic AI projects canceled by end of 2027 [4] | A tooling gap exists between demos and maintainable production systems. |
| Observability adoption | 89% of LangChain respondents report agent observability adoption; eval adoption 52% [2] | Teams can see traces, but still need deterministic replay and patch verification. |

---

## 2. The Actual Engineering Problem

The production debugging problem is not simply that LLM outputs vary. The deeper issue is that an agent execution is a chain of stochastic and mutable boundary crossings. A failed run is often a composite of model sampling, context construction, tool schemas, tool outputs, hidden SaaS state, database state, cache state, wall-clock time, and scheduling order. When an engineer later re-runs the same user prompt, they usually do not reproduce the same execution; they create a new execution with a similar first line.

Traditional software debugging assumes that a failing input can often be re-executed under controlled state. Agent debugging violates this assumption in four ways:

1. **Policy boundary nondeterminism.** The model may emit a different completion, tool call, or JSON argument even for similar inputs.
2. **Environment volatility.** Web APIs, databases, vector stores, and queues may have changed since the failure.
3. **Concurrent orchestration.** Multi-agent outputs may arrive in a different order.
4. **Cost and safety risk.** Naive replay can repeat charges, mutate production data, send webhooks, or expose secrets.

Therefore, the debugging target should not be the initial prompt alone. The debugging target should be the entire causal execution: the sequence and dependency graph of all boundary events that made the failure possible.

---

## 3. Empirical Evidence for Non-Determinism

Model-level nondeterminism is documented in both engineering documentation and empirical studies. Microsoft's Azure OpenAI reproducible-output documentation states that chat-completion responses are nondeterministic by default and that determinism is not guaranteed even with seed and `system_fingerprint` held constant; larger `max_tokens` values generally reduce determinism [5]. PyTorch's reproducibility documentation warns that complete reproducibility is not guaranteed across releases, commits, platforms, or CPU/GPU executions, even when seeds are identical [6].

Empirical software-engineering work also shows large output variation. Ouyang et al. studied 829 code-generation problems across CodeContests, APPS, and HumanEval and reported that the ratio of tasks with zero equal test output across repeated requests was 75.76%, 51.00%, and 47.56%, respectively. They also found that `temperature=0` did not guarantee deterministic code generation [7]. Recent work on token probability nondeterminism reports that GPU execution can produce nondeterministic results even when systems are configured for deterministic behavior, with meaningful probability variation for tokens whose probabilities are between roughly 0.1 and 0.9 [8].

For agents, nondeterminism matters more than for one-shot chat because each output becomes the next state. A single tool argument difference can change the database row read next, the retrieval documents inserted into the prompt, the next tool schema the model sees, or the branch chosen by a planner. This converts small local randomness into global path divergence.

---

## 4. Formal Model of Agent Execution

We model an agent as a stateful stochastic process interacting with an external mutable environment. At step `t`, let `H_t` be the agent history: system prompt, developer prompt, user input, tool definitions, prior model actions, prior tool observations, memories, retrieved documents, and intermediate planner state.

Let the model be a stochastic policy `pi_theta` parameterized by model weights `theta` and inference settings:

```text
phi_t = (temperature, top_p, max_tokens, seed, system_fingerprint, provider_state)
```

The model samples an action:

```text
A_t ~ pi_theta(. | H_t, phi_t)
```

The action can be a final answer, a tool invocation, a message to another agent, or an internal planning step. If the action crosses into an environment `E_t` with hidden state `S_t`, the environment returns observation `O_t` and transitions hidden state:

```text
O_t, S_{t+1} ~ P_E(. | S_t, A_t, W_t)
```

`W_t` represents unrecorded external variables: wall-clock time, request latency, upstream deployment version, cache state, rate limits, concurrent writes, queue ordering, and provider backend changes. The agent then updates history through deterministic or framework-defined update logic `f`:

```text
H_{t+1} = f(H_t, A_t, O_t)
```

A replay system succeeds only if it controls every non-deterministic boundary that can influence `H_{t+1}`. Agent-RR does this by converting boundary results into recorded facts during replay:

```text
Replay mode:  A_t := A_t^prod  and  O_t := O_t^prod  for matched boundary events
```

### 4.1 Cascading State Drift

If either the local action or observation differs at step `t`, then the next history differs:

```text
(A_t' != A_t) OR (O_t' != O_t)  =>  H_{t+1}' != H_{t+1}
```

Because the next model distribution is conditioned on history, a history difference changes the next action distribution:

```text
pi_theta(. | H_{t+1}', phi_{t+1}) != pi_theta(. | H_{t+1}, phi_{t+1})
```

This is the mathematical reason why naive prompt replay fails. The developer is not replaying the same run. They are sampling a new trajectory from a different conditional state distribution.

### 4.2 Probability of Exact Replay Failure

Let `D_t` be the event that local replay has diverged by step `t`. Suppose each step has an independent probability `p_t` of boundary mismatch if no record-and-replay system is used. Then the probability of exact replay through `n` steps is:

```text
P(no divergence through n) = Product_{t=1..n} (1 - p_t)
```

If `p_t = p` is constant, then:

```text
P(no divergence through n) = (1 - p)^n
P(divergence by n)      = 1 - (1 - p)^n
```

This exponential decay is the core long-horizon agent problem. Even small per-step mismatch rates become severe over many decisions. If `p = 0.05`, exact replay probability is about 60% after 10 steps, 36% after 20 steps, 7.7% after 50 steps, and 0.6% after 100 steps.

| Per-step mismatch `p` | 10 steps | 20 steps | 50 steps | 100 steps |
|---:|---:|---:|---:|---:|
| 1% | 90.4% exact | 81.8% exact | 60.5% exact | 36.6% exact |
| 2% | 81.7% exact | 66.8% exact | 36.4% exact | 13.3% exact |
| 5% | 59.9% exact | 35.8% exact | 7.7% exact | 0.6% exact |
| 10% | 34.9% exact | 12.2% exact | 0.5% exact | <0.1% exact |

This derivation also explains why production teams limit agents to a small number of steps and keep humans in the loop. The more steps an agent takes, the harder it becomes to reproduce, verify, and audit without a causal replay system.

---

## 5. Existing Tooling and the Gap

LLM observability platforms are valuable because they show what happened. LangSmith positions itself as an agent and LLM observability platform for tracing deeply nested agent behavior, and Phoenix describes tracing as capturing model calls, retrieval, tool use, and custom logic [9][10]. However, observability is mostly passive: it records and visualizes traces. It does not by itself guarantee that local code can re-execute a failed run with all live external effects blocked and historical values substituted.

HTTP cassette tools such as vcrpy record and replay HTTP interactions, which is useful for API tests [11]. But agent executions are not only HTTP. Tool calls may be local functions, database operations, MCP tool invocations, code execution, browser actions, or intra-agent messages. More importantly, transport cassettes do not understand why request #7 exists: they do not encode that it was causally downstream of model action #2. Agent-RR records at the agent boundary and stores `parent_event_ids`, not just URLs and bodies.

Traditional record-and-replay systems show that deterministic debugging is practical in conventional systems. Mozilla rr records nondeterministic process inputs and replays them for reverse debugging; the rr paper argues that if all inputs and nondeterminism are captured, replay can match the recorded execution [12]. Agent-RR adapts this insight to agent systems by defining the relevant boundary as the LLM/tool/environment boundary, not the CPU/kernel boundary.

| Capability | Standard logs | HTTP cassettes | LLM observability | Agent-RR |
|---|---:|---:|---:|---:|
| Records model/tool causality | No | No | Usually partial | Yes, explicit DAG |
| Replays without network | No | HTTP only | Usually no | Yes |
| Blocks production mutations | No | HTTP only | No | Yes |
| Local CI regression tests | Manual | API-level | Limited | Core use case |
| Explains upstream cause | No | No | Trace-dependent | Hash-linked parent diagnostics |
| Handles non-HTTP tools | No | No | Observe only | Yes |
| Handles multi-agent ordering | No | No | Visual only | Topological replay |

---

## 6. Agent-RR System Overview

Agent-RR has three layers: a **Production Flight Recorder**, a **Trace Storage Format**, and a **Local Replay Engine**. The Flight Recorder intercepts all non-deterministic boundaries during a live run. The Trace Storage Format persists each event as line-oriented JSONL with hashes and `parent_event_ids`. The Local Replay Engine loads the trace, validates its graph, blocks live network calls, and returns historical responses for matching local events.

```text
Production run:
  Agent -> Recorder -> LLM / Tool / API / DB
          Recorder writes event nodes to trace.jsonl

Local replay:
  Agent -> Replayer -> historical responses from trace.jsonl
          Live LLM/API/DB calls blocked by default
```

This architecture is aligned with the current Agent-RR README: the project records LLM calls and tool calls as a cryptographically hashed causal DAG in a plain JSONL file, supports replay with zero network calls, reports replay divergence with expected/actual payload diffs and upstream parent information, supports local-first operation, and is designed for git-friendly regression tests.

---

## 7. Causal DAG Trace Model

A flat log records temporal order; a DAG records causal dependency. For agent replay, causality matters more than wall-clock time. Lamport's classic distributed-systems work showed that the happened-before relation defines a partial ordering over events, not necessarily a single global wall-clock order [13]. Agent-RR applies the same principle to multi-agent executions.

Let `G = (V, E)` be the execution trace. Each vertex `v in V` is a boundary event. Each directed edge `(u, v) in E` means that `v` consumed information produced by `u`. Each node contains:

```text
event = {
  event_id,
  agent_id,
  event_type,
  name,
  parent_event_ids,
  payload,
  response,
  payload_hash,
  response_hash,
  context_hash,
  timestamp,
  redaction_policy,
  signature
}
```

The core invariant is acyclicity: no event may depend, directly or indirectly, on itself. Parent IDs create a partial order. Multiple valid topological orders may exist, which permits refactors that reorder independent branches while preserving semantic dependencies.

```text
Invariant 1:  G is a DAG.
Invariant 2:  For each event v, all parent_event_ids(v) exist in V.
Invariant 3:  context_hash(v) commits to payload(v), response(v), and parent context hashes.
Invariant 4:  Replay may execute v only after all parents of v have matched or been injected.
```

### 7.1 Recursive Hash Definition

Let `C(x)` be canonical JSON serialization: sorted keys, stable number policy, compact separators, and redaction before hashing. Let `H` be SHA-256 or HMAC-SHA256 when signing is enabled. For event `v`:

```text
payload_hash(v)  = H(C(payload(v)))
response_hash(v) = H(C(response(v)))
parent_hashes(v) = sorted([context_hash(u) for u in parents(v)])
context_hash(v)  = H(C({
    "event_type": type(v),
    "name": name(v),
    "payload_hash": payload_hash(v),
    "response_hash": response_hash(v),
    "parents": parent_hashes(v)
}))
```

This gives causal integrity. If a parent changes, every descendant `context_hash` changes. During replay, the system can localize the first node where the actual payload no longer matches the recorded payload and identify the nearest changed parent.

### 7.2 Topological Replay

A replay scheduler computes a valid topological order over `G`. Kahn's algorithm runs in `O(|V| + |E|)`. During replay, an event can be released only when its in-degree becomes zero, meaning all causal parents have matched.

```python
ready = [v for v in V if indegree(v) == 0]
while ready:
    v = ready.pop()
    match_or_raise_divergence(v)
    for child in children(v):
        indegree(child) -= 1
        if indegree(child) == 0:
            ready.append(child)
```

For multi-agent workflows, topological replay prevents race-condition drift. If two independent tool calls complete in a different wall-clock order locally, downstream synthesis is still blocked until the same causal join condition is satisfied.

---

## 8. Replay Modes

### 8.1 Strict Replay

Strict mode is forensic. The local event must match the recorded event exactly after canonicalization and redaction. If the hash differs, replay pauses and raises a `ReplayDivergence`.

```text
strict_match(v_local, v_prod) = [H(C(payload_local)) == payload_hash(v_prod)]
```

Strict mode answers: **where did the local execution first stop matching production?**

### 8.2 Structured Replay

Structured mode permits value churn while enforcing schema shape. It can match JSON keys and types but ignore volatile values such as timestamps, generated IDs, request IDs, and trace IDs.

```text
shape({"customer_id": 123, "limit": 5}) = {"customer_id": int, "limit": int}
```

Structured mode answers: **did the same kind of operation happen, even if volatile values changed?**

### 8.3 Semantic Replay

Semantic mode delegates matching to a user-provided matcher, such as an embedding similarity function or domain-specific equivalence check. It is intentionally explicit because semantic equivalence is application-specific and can hide real failures if used casually.

```text
semantic_match(recorded_payload, actual_payload) -> bool
```

Semantic mode answers: **is this new behavior close enough for the intended regression test?**

### 8.4 Manual Injection and Sandbox Fallback

When exact matching is not appropriate, the developer can inject a synthetic response or route the request to a safe staging environment. Production is never the fallback. This prevents replay from sending duplicate emails, charging credit cards, overwriting CRM records, or spending new model tokens.

---

## 9. Mathematical Reliability Framing

Agent-RR can be understood as reducing the entropy of the replay trajectory. Without replay, the trajectory `T = (A_1, O_1, ..., A_n, O_n)` is sampled from a high-entropy process conditioned on `H_0`. With replay, historical boundary outputs become constants, so the replay trajectory is deterministic until code intentionally produces a different boundary request.

```text
Without RR:  T ~ P(T | H_0, theta, E, W)
With RR:     T = T_prod  for all matched boundary events
```

Divergence detection becomes a hypothesis test over event payload equality. For event `v`, define `M_v = 1` if `payload_local(v)` matches `payload_prod(v)`, otherwise `0`. Strict replay fails at the first `v` in topological order where `M_v = 0`. Because `context_hash` commits to parents, the failure report can include the nearest upstream event whose changed output influenced `v`.

### 9.1 Expected Divergence Depth

Assume constant per-step mismatch probability `p` and independent steps. The expected number of matched steps before first divergence follows a geometric distribution:

```text
E[matched steps before divergence] = (1 - p) / p
```

For `p = 0.05`, the expected matched prefix is 19 steps. For `p = 0.10`, it is 9 steps. This is consistent with industry behavior: production systems often limit agent autonomy to short horizons and rely on humans when confidence drops.

### 9.2 Cost Model

Let `c_LLM(t)` be the token/API cost of the LLM call at step `t` and `c_tool(t)` the cost of external tool invocation. Naive regression testing over `R` test runs costs:

```text
Cost_naive = R * Sum_{t=1..n} [c_LLM(t) + c_tool(t)]
```

Agent-RR recording costs the live run once. Replaying `R` times costs approximately local CPU and disk I/O:

```text
Cost_RR = Sum_{t=1..n} [c_LLM(t) + c_tool(t)] + R * c_local_io
```

For CI, where `R` can be large across commits, branches, and pull requests, this converts recurring network/model cost into a one-time trace fixture cost. The bigger benefit is safety: `c_tool(t)` may include irreversible real-world side effects, not just money.

---

## 10. Trace Schema

A practical trace should be append-only, line-oriented, diffable, and streamable. JSONL is suitable because each event can be reviewed in a pull request and processed without loading a large trace into memory.

```json
{
  "schema_version": "agent-rr.trace.v1",
  "run_id": "run_2026_07_05_001",
  "event_id": "tool_call_3",
  "agent_id": "booking-agent",
  "event_type": "tool_call",
  "name": "search_flights",
  "parent_event_ids": ["llm_call_2"],
  "timestamp": "2026-07-05T03:42:12.431Z",
  "payload": {
    "from": "London",
    "to": "Tokyo",
    "limit": 5
  },
  "response": {
    "flights": ["JL042", "BA007"]
  },
  "payload_hash": "sha256:...",
  "response_hash": "sha256:...",
  "context_hash": "sha256:...",
  "redaction_policy": "default-v1",
  "signature": "hmac-sha256:..."
}
```

The README emphasizes that traces are git-friendly JSONL and can live in a `traces/` directory next to the code they protect. That choice is not cosmetic. It creates a reviewable test artifact: when a prompt or tool behavior changes intentionally, the trace diff is the behavioral diff.

---

## 11. Security, Privacy, and Compliance

A replay trace can contain prompts, tool arguments, tool responses, user records, customer identifiers, and error payloads. Therefore, redaction must happen before hashing and before storage. If secrets are hashed before redaction, the hash can still become a stable identifier for sensitive data. If secrets are stored before redaction, the trace is unsafe for git.

```text
raw_payload -> redactor -> canonical_json -> hash/sign -> optional encrypt -> write trace
```

Agent-RR should support: explicit user-provided redactors, stable placeholder replacement, optional HMAC signatures, optional payload encryption, retention policies, access-controlled trace retrieval, and metadata scrubbing. The README already describes redaction-before-hashing, optional tamper-evident signing, and optional encryption, which are the right primitives for a local-first tool that may store traces beside code.

Threat model: an attacker with repository write access may try to alter traces to hide a regression. Plain SHA-256 verifies internal consistency but not authorship because hashes can be recomputed. HMAC signatures with a secret CI key make trace tampering detectable. Encryption protects sensitive payloads at rest, while still allowing replay after decryption in authorized environments.

---

## 12. Evaluation Plan

A rigorous evaluation should measure determinism, divergence localization, overhead, trace size, replay speed, and developer usefulness. The minimum benchmark suite should contain single-agent flows, parallel tool fan-out/fan-in, multi-agent handoffs, tool errors, streaming LLM responses, HTTP calls, local function tools, and non-idempotent mutation attempts.

| Metric | Definition | Target |
|---|---|---|
| Replay determinism | Percent of strict replays producing identical final outputs and hashes | Near 100% for recorded deterministic boundaries |
| Divergence localization accuracy | Whether first reported divergence matches injected fault location | High precision in synthetic fault tests |
| Replay speedup | Live run wall-clock / replay wall-clock | Large improvement for network-heavy agents |
| Token/API cost avoided | Live API cost saved across CI replays | Approaches total recurring LLM/tool cost |
| Trace overhead | Record-time latency and bytes per event | Acceptable overhead for staging or selective production capture |
| Safety isolation | Number of live side effects during replay | Zero by default |
| DAG correctness | Cycle detection, missing-parent detection, topological invariants | All invalid traces rejected |
| Privacy correctness | Sensitive values present in trace after redaction | Zero in test corpus |

Fault injection is important. The evaluator should deliberately change a prompt, change a tool argument, reorder independent branches, remove a parent event, corrupt a hash, change a redaction policy, and simulate a tool exception. A useful replay system should accept safe branch reordering, reject corrupted traces, and explain intentional behavior drift at the first causally meaningful node.

---

## 13. Implementation Blueprint

### 13.1 Boundary API

```python
with Recorder(agent_id="support-agent", capture_to="traces/ticket.jsonl") as rr:
    answer = run_agent(rr, ticket_id="T-123")

with Replayer(trace_file="traces/ticket.jsonl", mode="strict") as rr:
    answer = run_agent(rr, ticket_id="T-123")
```

### 13.2 Tool Capture

```python
def record_tool_call(name, payload, fn, parent_event_ids=None):
    redacted_payload = redactor(payload)
    event_id = allocate_event_id(name)
    response = fn()                 # live only during record
    redacted_response = redactor(response)
    write_event(event_id, name, redacted_payload, redacted_response, parents)
    return response, event_id
```

### 13.3 Replay Capture

```python
def replay_tool_call(name, payload, parent_event_ids=None):
    redacted_payload = redactor(payload)
    event = next_matching_event(name, parent_event_ids)
    if not matcher(event.payload, redacted_payload):
        raise ReplayDivergence(expected=event.payload,
                               actual=redacted_payload,
                               parent=nearest_changed_parent(event))
    return event.response, event.event_id
```

---

## 14. Operational Challenges

### 14.1 Payload Bloat

Agent traces can be large because prompts, retrieved documents, tool schemas, and responses may be large. Mitigations include compression, object-storage offload for large payloads, content-addressed deduplication, payload truncation policies for observability-only fields, and streaming readers for JSONL. The current README notes line-by-line `iter_events` support for large traces, which is the correct storage direction.

### 14.2 Replay Deadlocks

A DAG replay scheduler can deadlock if an event waits on a parent that never appears locally. The system should distinguish invalid trace cycles from local code divergence. Missing parent events should fail during validation; local replay waiting too long for an expected event should fail with an actionable divergence report.

### 14.3 Non-Idempotent Mutations

The most dangerous replay bug is repeating a production mutation: sending an email, charging a card, modifying an account, deleting a file, opening a support ticket, or updating a CRM. The replayer should default to deny-all network and mutation boundaries. Any live fallback must be explicit and should route only to staging or a local sandbox.

### 14.4 Provider Drift

Even if a model provider exposes seed and backend fingerprint, deterministic behavior is usually best-effort rather than guaranteed [5]. Therefore, Agent-RR should not depend on provider-level reproducibility. It should record and replay the exact response payload that crossed the boundary.

### 14.5 Framework Coverage

Agents may be implemented with raw SDK calls, LangChain, LiteLLM, custom ReAct loops, MCP clients, browser automation, or local tools. The product should expose both low-level boundary APIs and optional wrappers. The README already points in this direction through OpenAI, Anthropic, LangChain, LiteLLM, requests, streaming, and `LoopRun` wrappers.

---

## 15. Limitations

Agent-RR is not a proof that an agent is correct. It is a deterministic regression and debugging layer. It can tell developers whether a code or prompt change deviated from recorded behavior, and it can allow patches to be tested under historical conditions. It cannot guarantee that the historical behavior was desirable, fair, safe, or complete. For that, teams still need evaluations, guardrails, human review, monitoring, and domain-specific acceptance tests.

Another limitation is trace representativeness. A trace is a fixture, not a distribution. If teams only record happy paths, replay tests will only protect happy paths. A mature workflow should build a trace corpus from production failures, edge cases, adversarial cases, and representative customer workflows.

---

## 16. Conclusion

Production AI agents create a debugging problem that traditional logs and normal test fixtures do not solve. The execution is stochastic, the environment is mutable, and multi-agent workflows introduce causal ordering problems. Empirical data suggests that teams already feel this pain: production agents are commonly short-horizon, human-evaluated, and quality-constrained [2][3].

Agent-RR turns the failed production run itself into a deterministic test artifact. By recording LLM calls, tool calls, and environment observations as a hash-linked causal DAG, then replaying them locally with live side effects blocked, developers gain a time machine for agent failures: inspect the original path, replay it, mutate code safely, locate the first divergence, and turn the failure into a permanent CI regression test. The core idea is simple: **record reality once, replay it forever.**

---

## References

[1] PwC. *AI Agent Survey*. May 2025. https://www.pwc.com/us/en/tech-effect/ai-analytics/ai-agent-survey.html

[2] LangChain. *State of Agent Engineering*. 12 June 2026. https://www.langchain.com/state-of-agent-engineering

[3] Pan, M. Z. et al. *Measuring Agents in Production*. arXiv:2512.04123, 2025. https://arxiv.org/abs/2512.04123

[4] Reuters. *Over 40% of agentic AI projects will be scrapped by 2027, Gartner says*. 25 June 2025. https://www.reuters.com/business/over-40-agentic-ai-projects-will-be-scrapped-by-2027-gartner-says-2025-06-25/

[5] Microsoft Learn. *Learn how to use reproducible output (preview) with Azure OpenAI*. Last updated 27 Feb 2026. https://learn.microsoft.com/en-us/azure/foundry-classic/openai/how-to/reproducible-output

[6] PyTorch Documentation. *Reproducibility*. https://docs.pytorch.org/docs/stable/notes/randomness.html

[7] Ouyang, S., Zhang, J. M., Harman, M., and Wang, M. *An Empirical Study of the Non-determinism of ChatGPT in Code Generation*. arXiv:2308.02828, 2023. https://arxiv.org/abs/2308.02828

[8] Fu, T. et al. *Beyond Reproducibility: Token Probabilities Expose Large Language Model Nondeterminism*. arXiv:2601.06118, 2026. https://arxiv.org/abs/2601.06118

[9] LangChain. *LangSmith Observability*. https://www.langchain.com/langsmith/observability

[10] Arize AI. *What is Arize Phoenix?* https://arize.com/docs/phoenix

[11] vcrpy Documentation. *Usage*. https://vcrpy.readthedocs.io/en/latest/usage.html

[12] O'Callahan, R. et al. *Engineering Record And Replay For Deployability*. USENIX ATC 2017. https://www.usenix.org/system/files/conference/atc17/atc17-o_callahan.pdf

[13] Lamport, L. *Time, Clocks, and the Ordering of Events in a Distributed System*. Communications of the ACM, 21(7), 558-565, 1978. https://lamport.azurewebsites.net/pubs/time-clocks.pdf

[14] Model Context Protocol. *Specification 2025-11-25*. https://modelcontextprotocol.io/specification/2025-11-25

[15] Model Context Protocol. *Base Protocol Overview*. https://modelcontextprotocol.io/specification/2025-11-25/basic

[16] Model Context Protocol. *Tools*. https://modelcontextprotocol.io/specification/draft/server/tools

[17] Rabanser, S. et al. *Towards a Science of AI Agent Reliability*. arXiv:2602.16666, 2026. https://arxiv.org/abs/2602.16666

[18] Mohammadi, M., Li, Y., Lo, J., and Yip, W. *Evaluation and Benchmarking of LLM Agents: A Survey*. arXiv:2507.21504, 2025. https://arxiv.org/abs/2507.21504

[19] Apostolou, S. A., Bosch, J., and Olsson, H. H. *Agentic AI in Industry: Adoption Level and Deployment Barriers*. arXiv:2605.14675, 2026. https://arxiv.org/abs/2605.14675

[20] Agent-RR README. `github.com/INo-xious/y-combinator-hackathon`, uploaded project README.
